#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include "mysql.h"

#pragma comment(lib, "libmysql.lib")

const char* host = "localhost";
const char* user = "root";
const char* pw = "989098";
const char* db = "new_schema";

MYSQL* connection = NULL;
MYSQL conn;
MYSQL_RES* sql_result;
MYSQL_ROW sql_row;

void type1()
{
	int k = 0, t = 0, state = 0;

	printf("-------- TYPE 1 --------\n\n");
	printf("** Assume the package shipped by USPS with tracking number X is reported to have been destroyed in an accident. Find the contact information for the customer.**\n");
	while (1) {


		char q1[500];
		
		sprintf(q1, "SELECT * from Deliver_info"); //query
		state = 0;
		state = mysql_query(connection, q1);
		if (state == 0) {
			sql_result = mysql_store_result(connection);

			printf("===============================================================\n");
			printf(" \n");
			printf("===============================================================\n");
			while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
			{
				printf("%3s   %3s    %3s\n", sql_row[0], sql_row[1], sql_row[2]);
			}
			printf("\n");
			mysql_free_result(sql_result);
		}

		printf("\n----------- TYPE 1-1 -----------\n\n");
		printf("** Then find the contents of that shipment and create a new shipment of replacement items. **\n");
		printf("** 0 : exit **\n** 1 : show results **\nInput : ");

			char q11[500];
			

			state = 0;
			state = mysql_query(connection, q11);
			if (state == 0) {
				sql_result = mysql_store_result(connection);

				printf("=============================================================================\n");
				printf("  \n");
				printf("=============================================================================\n");
				while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
				{
					printf("%12s           %s           %9s           %4s            %s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3], sql_row[4]);
				}
				printf("\n");
				mysql_free_result(sql_result);
			}

		break;
	}
	return;
}

void type2()
{
	/*int k = 0, t = 0, state = 0, inp = 0;

	printf("-------- TYPE 2 --------\n\n");
	printf("** Find the customer who has bought the most (by price) in the past year. **\n");
	while (1) {


		char q2[500];


		state = 0;
		state = mysql_query(connection, q2);
		if (state == 0) {
			sql_result = mysql_store_result(connection);

			printf("===============================================================\n");
			printf(" \n");
			printf("===============================================================\n");
			while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
			{
				printf("%12s           %s           %9s            %4s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
			}
			printf("\n");
			mysql_free_result(sql_result);
		}

		printf("\n----------- TYPE 2-1 -----------\n\n");
		printf("** Then find the product that the customer bought the most. **\n");
		printf("** 0 : exit **\n** 1 : show results **\nInput : ");
		scanf("%d", &inp);
		if (inp == 1) {
			char q21[500];


			state = 0;
			state = mysql_query(connection, q21);
			if (state == 0) {
				sql_result = mysql_store_result(connection);

				printf("=============================================================================\n");
				printf("  \n");
				printf("=============================================================================\n");
				while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
				{
					printf("%12s           %s           %9s           %4s            %s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3], sql_row[4]);
				}
				printf("\n");
				mysql_free_result(sql_result);
			}
		}
	}
	return;*/

}

void type3()
{
	int k = 0, t = 0, state = 0;
	printf("-------- TYPE 3 --------\n\n");
	printf("** Find all products sold in the past year. **\n");
	while (1) {
		char q3[500];
		sprintf(q3, "SELECT * from sales where YEAR(time) = '2021'");
		state = 0;
		state = mysql_query(connection, q3);
		if (state == 0) {
			sql_result = mysql_store_result(connection);
			printf("**Past year's sold products **\n ");
			printf("P_ID     company_name     sale_price\n");
			printf("----------------------------------\n");
			while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
				printf("%7s, %8s, %12s\n", sql_row[0], sql_row[1], sql_row[2]);
			}
			printf("\n");
			mysql_free_result(sql_result);
		}

	//subtype start//
		printf("------- Subtypes in TYPE 3 -------\n\n");
		printf("\t1. TYPE 3-1.\n");
		printf("\t2. TYPE 3-2.\n");
		printf("----------------------------------\n\n");
		printf("\n----------- TYPE 3-1 -----------\n\n");
		printf("Input K? : ");
		scanf("%d", &k);
		if (k == 0) {
			printf("\n\ninvalid k!!\n\n");
			break;
		}
		char q31[500];
		sprintf(q31, "SELECT * from sales where YEAR(time) = '2021' order by sale_price desc limit %d", k);
		state = 0;
		state = mysql_query(connection, q31);
		if (state == 0) {
			sql_result = mysql_store_result(connection);
			printf("\n(TYPE 3-1)top k products by dollar-amount sold\n\n");
			printf("P_ID     company_name     sale_price\n");
			printf("----------------------------------\n");
			while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
				printf("%7s, %8s, %12s\n", sql_row[0], sql_row[1], sql_row[2]);
			}
			printf("\n");
			mysql_free_result(sql_result);
		}
			
		printf("\n----------- TYPE 3-2 -----------\n");
		char q32[500];
		sprintf(q32, "select * from (select P_ID, company_name, sale_price, PERCENT_RANK() over(order by sale_price desc) as per_rank from sales where YEAR(time) = '2021') a where a.per_rank <= 0.1");
		state = 0;
		state = mysql_query(connection, q32);
		if (state == 0) {
			sql_result = mysql_store_result(connection);
			printf("\n\n(TYPE 3-2) top 10 percent products by dollar-amount sold\n\n");
			printf("P_ID     company_name     sale_price\n");
			printf("----------------------------------\n");
			while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
				printf("%7s, %8s, %12s\n", sql_row[0], sql_row[1], sql_row[2]);
			}
			printf("\n");
			mysql_free_result(sql_result);
		}
		break;

	}
	return;
}

void type4()
{
	int k = 0, t = 0, state = 0;
	printf("-------- TYPE 4 --------\n\n");
	printf("** Find all products by unit sales in the past year.  **\n");
	while (1) {
		char q4[500];
		sprintf(q4, "SELECT * from sales where YEAR(time) = '2021'");
		state = 0;
		state = mysql_query(connection, q4);
		if (state == 0) {
			sql_result = mysql_store_result(connection);
			printf("**Past year's sold products **\n ");
			printf("P_ID     company_name     sale_price\n");
			printf("----------------------------------\n");
			while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
				printf("%7s, %8s, %12s\n", sql_row[0], sql_row[1], sql_row[2]);
			}
			printf("\n");
			mysql_free_result(sql_result);
		}

		//subtype start//
		printf("------- Subtypes in TYPE 4 -------\n\n");
		printf("\t1. TYPE 4-1.\n");
		printf("\t2. TYPE 4-2.\n");
		printf("----------------------------------\n\n");
		printf("\n----------- TYPE 4-1 -----------\n\n");
		printf("Input K? : ");
		scanf("%d", &k);
		if (k == 0) {
			printf("\n\ninvalid k!!\n\n");
			break;
		}
		char q41[500];
		sprintf(q41, "SELECT * from sales where YEAR(time) = '2021' order by sale_price desc limit %d", k);
		state = 0;
		state = mysql_query(connection, q41);
		if (state == 0) {
			sql_result = mysql_store_result(connection);
			printf("\n(TYPE 4-1)top k products by dollar-amount unit sales\n\n");
			printf("P_ID     company_name     sale_price\n");
			printf("----------------------------------\n");
			while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
				printf("%7s, %8s, %12s\n", sql_row[0], sql_row[1], sql_row[2]);
			}
			printf("\n");
			mysql_free_result(sql_result);
		}

		printf("\n----------- TYPE 4-2 -----------\n");
		char q42[500];
		sprintf(q42, "select * from(select P_ID, company_name, sale_price, PERCENT_RANK() over(order by sale_price desc) as per_rank from sales where YEAR(time) = '2021') a where a.per_rank <= 0.1");
		state = 0;
		state = mysql_query(connection, q42);
		if (state == 0) {
			sql_result = mysql_store_result(connection);
			printf("\n\n(TYPE 4-2) top 10 percent products by dollar-amount sold\n\n");
			printf("P_ID     company_name     sale_price\n");
			printf("----------------------------------\n");
			while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
				printf("%7s, %8s, %12s\n", sql_row[0], sql_row[1], sql_row[2]);
			}
			printf("\n");
			mysql_free_result(sql_result);
		}
		break;

	}
	return;

}

void type5()
{
	/*int k = 0, y = 0;
	printf("-------- TYPE 5 --------\n\n");
	printf("** Find those products that are out-of-stock at every store in California. **\n");
	while (1) {

		
		char q5[500];

		int state = 0;
		state = mysql_query(connection, q5);
		if (state == 0) {
			sql_result = mysql_store_result(connection);
			printf("=============================\n");

			printf("=============================\n");
			while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
			{
				printf("%12s           %s\n", sql_row[0], sql_row[1]);
			}

			printf("\n");
			mysql_free_result(sql_result);
		}

	}
	return;*/


}

void type6()
{
	/*int k = 0, y = 0;
	printf("-------- TYPE 6 --------\n\n");
	printf("** Find those packages that were not delivered within the promised time. **\n");
	while (1) {


		char q6[500];

		int state = 0;
		state = mysql_query(connection, q6);
		if (state == 0) {
			sql_result = mysql_store_result(connection);
			printf("=============================\n");

			printf("=============================\n");

			while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
			{
				printf("%12s           %s\n", sql_row[0], sql_row[1]);
			}

			printf("\n");
			mysql_free_result(sql_result);
		}

	}
	return;*/
}

void type7()
{
	/*int k = 0, y = 0;
	printf("-------- TYPE 7 --------\n\n");
	printf("** Generate the bill for each customer for the past month. **\n");
	while (1) {


		char q7[500];

		int state = 0;
		state = mysql_query(connection, q7);
		if (state == 0) {
			sql_result = mysql_store_result(connection);
			printf("=============================\n");

			printf("=============================\n");

			while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
			{
				printf("%12s           %s\n", sql_row[0], sql_row[1]);
			}

			printf("\n");
			mysql_free_result(sql_result);
		}

	}
	return;*/


}


int main(void) {
	if (mysql_init(&conn) == NULL)
		printf("mysql_init() error!");
	connection = mysql_real_connect(&conn, host, user, pw, db, 3306, (const char*)NULL, 0);
	if (connection == NULL)
	{
		printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
		return 1;
	}
	// connection success
	else
	{
		printf("Connection Succeed\n");
		// select database
		if (mysql_select_db(&conn, db))
		{
			printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
			return 1;
		}
		// open CRUID file
		FILE* fp = fopen("20170624.txt", "r");
		char temp[500];
		// read a line and execute query until EOF
		while (1) {
			if (feof(fp)) break;
			fgets(temp, 500, fp);
			mysql_query(connection, temp);
		}
		if (temp != NULL)
			mysql_query(connection, temp);
		fclose(fp);

		int typeno;

		// start the program until user select quit menu
		while (1) {
			printf("-------- SELECT QUERY TYPES --------\n\n");
			printf("\t1. TYPE 1\n");
			printf("\t2. TYPE 2\n");
			printf("\t3. TYPE 3\n");
			printf("\t4. TYPE 4\n");
			printf("\t5. TYPE 5\n");
			printf("\t6. TYPE 6\n");
			printf("\t7. TYPE 7\n");
			printf("\t0. QUIT\n");

			scanf("%d", &typeno);
			if (typeno == 0) break;
			else if (typeno == 1) type1();
			else if (typeno == 2) type2();
			else if (typeno == 3) type3();
			else if (typeno == 4) type4();
			else if (typeno == 5) type5();
			else if (typeno == 6) type6();
			else if (typeno == 7) type7();
			else printf("Invalid type number\n");
		}

		// delete & drop table
		
		fp = fopen("20170624_2.txt", "r");

		while (1) {
				if (feof(fp)) break;
				fgets(temp, 500, fp);
				mysql_query(connection, temp);
		}
		fclose(fp);
		mysql_close(connection);
		
	}

	return 0;
}